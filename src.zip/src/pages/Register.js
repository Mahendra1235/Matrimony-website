import React from 'react';
import ProfileForm from '../components/ProfileForm';

const Register = () => {
  return (
    <div>
      <ProfileForm />
    </div>
  );
};

export default Register;
