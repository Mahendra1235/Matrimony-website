import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';

const MatchList = () => {
  const [matches, setMatches] = useState([]);

  const navigate = useNavigate(); 

  useEffect(() => {
    setMatches([
      { name: 'Harish', age: 30, interests: 'Music, Travel', Occupation: 'Civil Engineer', profilepicture: 'https://randomuser.me/api/portraits/men/58.jpg' },
      { name: 'Priyanka', age: 28, interests: 'Reading, Yoga', Occupation: 'Architect',profilepicture: 'https://randomuser.me/api/portraits/women/84.jpg' },
      { name: 'Naveen', age: 28, interests: 'Gym', Occupation: 'Software Engineer.', profilepicture: 'https://randomuser.me/api/portraits/men/65.jpg' },
      { name: 'Tariq', age: 30, interests: 'Photography', Occupation: 'Photographer', profilepicture: 'https://randomuser.me/api/portraits/men/50.jpg' },
      { name: 'Manasa', age: 35, interests: 'Cooking', Occupation: 'Freelancer', profilepicture: 'https://randomuser.me/api/portraits/women/15.jpg' },
      { name: 'Karthik', age: 35, interests: 'Movies', Occupation: 'Movie Director', profilepicture: 'https://randomuser.me/api/portraits/men/69.jpg' },
    ]);
  }, []);

  const handleViewClick = (index) => {
    navigate(`/viewmatchlist/${index}`);
  };

  return (
    <div>
      <div className="Welcome-msg">
        <h2>Welcome User,</h2>
        <p>Find your matches here</p>
      </div>

      <div className="d-flex flex-wrap">
        {matches.map((match, index) => (
          <div className="match-card" key={index}>
            <img src={match.profilepicture} alt="Profile" />
            <h3>{match.name}</h3>
            <p>Age: {match.age}</p>
            <p>Interests: {match.interests}</p>
            <button className="btn" onClick={() => handleViewClick(index)}>View</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MatchList;
