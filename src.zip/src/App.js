import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Register from './pages/Register';
import Matches from './pages/MatchList';
import Profile from './pages/Profile';
import Header from './components/Header';
import Footer from './components/Footer';
import About from './pages/About';
import Login from './pages/Login';
import ViewMatchList from './pages/ViewMatchList'
import Chat from './pages/Chat';
import Support from './pages/Support';
import FAQCreateProfile from './pages/FAQCreateProfile';
import FAQContactMatch from './pages/FAQContactMatch';
import FAQTechnicalIssues from './pages/FAQTechnicalIssues';

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About/>} />
        <Route path="/register" element={<Register />} />
        <Route path="/support" element={<Support />} />
        <Route path="/matches" element={<Matches />} />
        <Route path="/login" element={<Login />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/viewmatchlist/:id" element={<ViewMatchList />} />
        <Route path="/faq/create-profile" element={<FAQCreateProfile />} />
        <Route path="/faq/contact-match" element={<FAQContactMatch />} />
        <Route path="/faq/technical-issues" element={<FAQTechnicalIssues />} />

      </Routes>
    </Router>
  );
}

export default App;
